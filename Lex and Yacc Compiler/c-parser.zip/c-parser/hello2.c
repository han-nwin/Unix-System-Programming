int main()
{
	int i,j,x;
	int y = 1;
	for (i=0; i<10;i++){
	   y++;
	}
	if (y == 10) {
	   x--;
	}
	printf("Hello World\n"); 
}
