#define print 257
#define exit_command 258
#define number 259
#define identifier 260
typedef union {int num; char id;} YYSTYPE;
extern YYSTYPE yylval;
