#include <stdio.h>
#include <stdlib.h>   
int main()
{
// this is richard min
	printf("Hello World\n");   // waw hello Richard and ok
 	exit(0);         // end of the program
}
